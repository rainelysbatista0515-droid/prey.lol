/*
  PASTE YOUR SUPABASE PROJECT VALUES HERE.

  Project URL:
  Supabase Dashboard -> Project Settings -> API -> Project URL

  Anon key:
  Supabase Dashboard -> Project Settings -> API -> Publishable/anon key

  NEVER put a service_role/secret key in this file.
*/
window.SUPABASE_URL = "PASTE_PROJECT_URL_HERE";
window.SUPABASE_ANON_KEY = "PASTE_ANON_OR_PUBLISHABLE_KEY_HERE";
