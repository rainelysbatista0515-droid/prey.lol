const client = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);

const fallback = {
  name: "yourname",
  username: "@yourname",
  bio: "welcome to my little corner of the internet ♡",
  avatar_url: "https://placehold.co/240x240/171321/e95bb5?text=♡",
  background_url: "",
  accent: "#e84fae",
  accent2: "#8e48e8",
  show_status: true,
  song_title: "your song",
  song_artist: "your artist",
  music_url: "",
  music_enabled: false,
  links: [
    {icon:"◉", name:"Discord", url:"https://discord.com/"},
    {icon:"◈", name:"Roblox", url:"https://www.roblox.com/"}
  ],
  badges: ["✦ creator", "♡ online"]
};

const $ = id => document.getElementById(id);

function setTheme(p) {
  document.documentElement.style.setProperty("--accent", p.accent || fallback.accent);
  document.documentElement.style.setProperty("--accent2", p.accent2 || fallback.accent2);
  const bg = $("background");
  if (p.background_url) {
    const url = p.background_url.replace(/"/g, "%22");
    bg.style.backgroundImage = `linear-gradient(rgba(7,5,12,.42),rgba(7,5,12,.72)),url("${url}")`;
  } else {
    bg.style.backgroundImage = "";
  }
}

function render(p, views) {
  $("pageTitle").textContent = `${p.name || "Bio"} — bio`;
  $("metaDescription").content = p.bio || "";
  $("name").textContent = p.name || "";
  $("handle").textContent = p.username || "";
  $("bio").textContent = p.bio || "";
  $("avatar").src = p.avatar_url || fallback.avatar_url;
  $("statusDot").hidden = !p.show_status;

  $("badges").innerHTML = "";
  (p.badges || []).forEach(b => {
    const span = document.createElement("span");
    span.textContent = b;
    $("badges").appendChild(span);
  });

  $("links").innerHTML = "";
  (p.links || []).forEach(l => {
    if (!l.url || !l.name) return;
    const a = document.createElement("a");
    a.className = "link";
    a.href = l.url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    a.innerHTML = `<span class="icon"></span><span>${escapeHtml(l.name)}</span>`;
    a.querySelector(".icon").textContent = l.icon || "↗";
    $("links").appendChild(a);
  });

  const enabled = Boolean(p.music_enabled && p.music_url);
  $("musicBox").classList.toggle("hidden", !enabled);
  if (enabled) {
    $("songTitle").textContent = p.song_title || "Song";
    $("songArtist").textContent = p.song_artist || "Artist";
    $("audio").src = p.music_url;
  }
  $("views").textContent = `${Number(views || 0).toLocaleString()} views`;
  setTheme(p);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

async function load() {
  if (!window.SUPABASE_URL.startsWith("http")) {
    render(fallback, 0);
    return;
  }

  const { data: profile } = await client.from("profiles").select("*").eq("id", 1).maybeSingle();
  const { data: links } = await client.from("links").select("*").eq("profile_id", 1).order("sort_order");
  const { data: badges } = await client.from("badges").select("*").eq("profile_id", 1).order("sort_order");
  const { data: stats } = await client.from("site_stats").select("views").eq("id", 1).maybeSingle();

  const p = {...fallback, ...(profile || {})};
  p.links = links?.length ? links : fallback.links;
  p.badges = badges?.length ? badges.map(x => x.label) : fallback.badges;
  render(p, stats?.views || 0);

  await client.rpc("increment_views");
  if (stats) $("views").textContent = `${Number(stats.views + 1).toLocaleString()} views`;
}

$("playBtn").addEventListener("click", async () => {
  const audio = $("audio");
  if (audio.paused) {
    try {
      await audio.play();
      $("playBtn").textContent = "❚❚";
      $("musicBox").classList.add("playing");
    } catch {
      alert("The audio URL could not be played. Use a direct .mp3/.ogg/.wav URL.");
    }
  } else {
    audio.pause();
    $("playBtn").textContent = "▶";
    $("musicBox").classList.remove("playing");
  }
});

load();
