const client = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
const $ = id => document.getElementById(id);
let links = [];
let badges = [];

function msg(id, text, ok=false) {
  $(id).textContent = text;
  $(id).className = "message " + (ok ? "ok" : "error");
}

async function init() {
  if (!window.SUPABASE_URL.startsWith("http")) {
    $("loginCard").hidden = false;
    msg("loginMsg", "First fill in config.js with your Supabase URL and anon/publishable key.");
    return;
  }

  const { data: { session } } = await client.auth.getSession();
  if (session) showDashboard();
  else $("loginCard").hidden = false;
}

async function showDashboard() {
  $("loginCard").hidden = true;
  $("dashboard").hidden = false;

  const { data: p } = await client.from("profiles").select("*").eq("id", 1).maybeSingle();
  const { data: l } = await client.from("links").select("*").eq("profile_id", 1).order("sort_order");
  const { data: b } = await client.from("badges").select("*").eq("profile_id", 1).order("sort_order");
  const { data: s } = await client.from("site_stats").select("views").eq("id", 1).maybeSingle();

  if (p) {
    ["name","username","bio","avatar_url","background_url","accent","accent2","song_title","song_artist","music_url"].forEach(k => {
      if ($(k)) $(k).value = p[k] ?? "";
    });
    $("show_status").checked = p.show_status !== false;
    $("music_enabled").checked = p.music_enabled === true;
  }
  links = l || [];
  badges = (b || []).map(x => x.label);
  renderLinks();
  renderBadges();
  $("viewCount").textContent = Number(s?.views || 0).toLocaleString();
}

function renderLinks() {
  $("linkEditor").innerHTML = "";
  links.forEach((l, i) => {
    const row = document.createElement("div");
    row.className = "editor-row";
    row.innerHTML = `
      <input class="link-icon" value="${esc(l.icon || "↗")}" aria-label="Icon">
      <input class="link-name" value="${esc(l.name || "")}" placeholder="Name">
      <input class="link-url" value="${esc(l.url || "")}" placeholder="https://...">
      <button type="button" class="danger" data-i="${i}">×</button>`;
    row.querySelector(".danger").onclick = () => { links.splice(i,1); renderLinks(); };
    $("linkEditor").appendChild(row);
  });
}

function renderBadges() {
  $("badgeEditor").innerHTML = "";
  badges.forEach((b, i) => {
    const row = document.createElement("div");
    row.className = "editor-row";
    row.innerHTML = `<input value="${esc(b)}" placeholder="✦ creator"><button type="button" class="danger">×</button>`;
    row.querySelector("input").oninput = e => badges[i] = e.target.value;
    row.querySelector(".danger").onclick = () => { badges.splice(i,1); renderBadges(); };
    $("badgeEditor").appendChild(row);
  });
}

function esc(s) {
  return String(s).replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;");
}

$("loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  msg("loginMsg", "Signing in...");
  const { error } = await client.auth.signInWithPassword({
    email: $("email").value,
    password: $("password").value
  });
  if (error) return msg("loginMsg", error.message);
  showDashboard();
});

$("logout").onclick = async () => {
  await client.auth.signOut();
  location.reload();
};

$("profileForm").addEventListener("submit", async e => {
  e.preventDefault();
  const row = {
    id: 1,
    name: $("name").value.trim(),
    username: $("username").value.trim(),
    bio: $("bio").value.trim(),
    avatar_url: $("avatar_url").value.trim(),
    background_url: $("background_url").value.trim(),
    accent: $("accent").value,
    accent2: $("accent2").value,
    show_status: $("show_status").checked
  };
  const { error } = await client.from("profiles").upsert(row);
  msg("profileMsg", error ? error.message : "Profile saved.", !error);
});

$("musicForm").addEventListener("submit", async e => {
  e.preventDefault();
  const row = {
    id: 1,
    song_title: $("song_title").value.trim(),
    song_artist: $("song_artist").value.trim(),
    music_url: $("music_url").value.trim(),
    music_enabled: $("music_enabled").checked
  };
  const { error } = await client.from("profiles").upsert(row);
  msg("musicMsg", error ? error.message : "Music saved.", !error);
});

$("addLink").onclick = () => {
  links.push({icon:"↗", name:"New link", url:"https://"});
  renderLinks();
};

$("saveLinks").onclick = async () => {
  links = [...document.querySelectorAll("#linkEditor .editor-row")].map(row => ({
    profile_id: 1,
    icon: row.querySelector(".link-icon").value.trim(),
    name: row.querySelector(".link-name").value.trim(),
    url: row.querySelector(".link-url").value.trim()
  })).filter(x => x.name && x.url);

  const del = await client.from("links").delete().eq("profile_id", 1);
  if (del.error) return msg("linksMsg", del.error.message);
  const { error } = links.length ? await client.from("links").insert(links.map((x,i)=>({...x,sort_order:i}))) : {error:null};
  msg("linksMsg", error ? error.message : "Links saved.", !error);
};

$("addBadge").onclick = () => { badges.push("✦ new badge"); renderBadges(); };

$("saveBadges").onclick = async () => {
  badges = badges.filter(Boolean);
  const del = await client.from("badges").delete().eq("profile_id", 1);
  if (del.error) return msg("badgesMsg", del.error.message);
  const rows = badges.map((label,i)=>({profile_id:1,label,sort_order:i}));
  const { error } = rows.length ? await client.from("badges").insert(rows) : {error:null};
  msg("badgesMsg", error ? error.message : "Badges saved.", !error);
};

init();
