# Advanced Bio Page — GitHub Pages + Supabase

This project gives you:
- public profile page
- real admin login
- database-backed profile settings
- editable name/username/bio
- avatar and background URL
- colors
- Discord/Roblox/social links
- badges
- music player
- real database page-view counter

## 1. Create Supabase project

Create a free Supabase project at https://supabase.com/

Open SQL Editor and run the entire `supabase.sql` file.

## 2. Create your admin account

In Supabase:
Authentication -> Users -> Add user

Create the email/password you want to use for `/admin.html`.

You do NOT put the password into the website files.

## 3. Add your project keys

Open `config.js` and replace:

PASTE_PROJECT_URL_HERE
PASTE_ANON_OR_PUBLISHABLE_KEY_HERE

Use the Project URL and the public anon/publishable key from:
Project Settings -> API.

NEVER put a service_role/secret key into `config.js`.

## 4. Upload to GitHub

Upload:
- index.html
- admin.html
- app.js
- admin.js
- config.js
- style.css
- admin.css
- supabase.sql

The SQL file is only for setup and does not need to be public for the site to work.

## 5. Turn on GitHub Pages

Repository -> Settings -> Pages -> Deploy from a branch -> main -> / (root).

Your public page will be:
https://YOUR-GITHUB-USERNAME.github.io/YOUR-REPOSITORY/

Your editor will be:
https://YOUR-GITHUB-USERNAME.github.io/YOUR-REPOSITORY/admin.html

## 6. Custom domain

After the GitHub Pages site works, add your domain under:
Repository -> Settings -> Pages -> Custom domain.

Your registrar DNS records must point to GitHub Pages according to GitHub's current custom-domain instructions.

## 7. Important security note

This setup intentionally uses only the public Supabase key in the browser. The admin password is handled by Supabase Auth.

Do not expose a Supabase service_role/secret key in HTML, CSS, JavaScript, GitHub, or GitHub Pages.

## 8. Editing your page

Go to `/admin.html`, sign in, change your settings, and click Save. The public page reads the new values from the database.

For images/music, use URLs that allow direct browser access. For a more complete upload system, add Supabase Storage later.
